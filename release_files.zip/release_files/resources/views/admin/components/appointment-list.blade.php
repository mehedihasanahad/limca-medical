<div class="br-section-wrapper">
    <h1> Appointment List</h1>
    <br/>
    <br/>
    <div class="table-wrapper" style="overflow-x:auto;">
        <table class="table table-bordered appointment-data-table">
            <thead>
            <tr>
                <th>ID</th>
                <th>Slip no</th>
                <th>Medical</th>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Date of Birth</th>
                <th>Nationality</th>
                <th>Gender</th>
                <th>Passport Number</th>
{{--                <th>Passport Issue Place</th>--}}
{{--                <th>Passport Expiry Date</th>--}}
{{--                <th>Visa Type</th>--}}
                <th>Email</th>
{{--                <th>Phone</th>--}}
{{--                <th>National ID</th>--}}
{{--                <th>Position</th>--}}
{{--                <th>Other</th>--}}
            </tr>
            </thead>
            <tbody>

            </tbody>
        </table>
    </div><!-- table-wrapper -->

</div>
