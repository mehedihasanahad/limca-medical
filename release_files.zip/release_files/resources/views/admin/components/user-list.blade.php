<div class="br-section-wrapper">
    <h1> User List</h1>
    <br/>
    <br/>
    <div class="table-wrapper">
        <table class="table table-bordered user-data-table">
            <thead>
            <tr>
                <th>Action</th>
                <th>User Name</th>
                <th>Role</th>
                <th>Created On</th>
                <th>Medical Center Name</th>
            </tr>
            </thead>
            <tbody>
            </tbody>
        </table>
    </div><!-- table-wrapper -->

</div>
