<img style="height: 50px; width:50px; border-radius:10px" src='{{url($row->medical_centre_logo)}}'>
