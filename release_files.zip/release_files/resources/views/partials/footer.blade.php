<footer style="height: 200px; background: #333333; color: white;">
    <div class="d-flex align-items-center flex-column justify-content-center" style="height: 100%;">
        <div class="social-media-icons" style="font-size: 20px;">
            <i class="fa fa-instagram"></i>
            <i class="fa fa-facebook"></i>
            <i class="fa fa-twitter"></i>
            <i class="fa fa-youtube"></i>

        </div>
        <div>
            <div>
                <span>@ 2024 </span>
                LIMCA. All rights reserved
            </div>
        </div>
    </div>
</footer>
